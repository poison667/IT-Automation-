import sys
import os
import time
import threading
import webbrowser

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from api.src.main import app
import uvicorn

def run_api():
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="warning")

if __name__ == "__main__":
    t = threading.Thread(target=run_api, daemon=True)
    t.start()
    time.sleep(1.2)
    
    try:
        import webview
        window = webview.create_window(
            "NexusIT Enterprise Autonomous Platform",
            "http://127.0.0.1:8000",
            width=1360,
            height=860,
            min_size=(1024, 700),
            background_color="#0B0E14"
        )
        webview.start()
    except Exception:
        webbrowser.open("http://127.0.0.1:8000")
        t.join()
